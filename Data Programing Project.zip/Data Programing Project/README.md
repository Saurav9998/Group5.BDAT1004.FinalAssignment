# Step 1 : acquiring data and storing them into database

- Excel data

  eg. https://wpreportbuilder.com/examples/students-exam-marks-list-generate-excel-xlsx/

- JSON Data

  eg. https://gilded-sunflower-students.netlify.app/data.json

- storing into db

  https://console.firebase.google.com/

- To Delete Data stored in db

  DELETE Req

  https://dataprogrammingpro.herokuapp.com/api/students/

- To fetch data from website and store into database

  https://dataprogrammingpro.herokuapp.com/fetchandstoreindb/

# step 2

- Firebase Database connection

- Auto Fetch Data every 24 hrs (Not Done)

- describe process/ functions

  - refer datapro >> fetchandstoreindb >> views.py

  - refer datapro >> api_app >> views.py

  - GET All Students Data (GET Req)
    https://dataprogrammingpro.herokuapp.com/api/students/

  - POST A Student Data (POST Req)
    https://dataprogrammingpro.herokuapp.com/api/students/

  - GET Range Of Data (GET Req)
    https://dataprogrammingpro.herokuapp.com/api/students/?from=220009&to=220010

  - Delete All Students Data (DELETE Req)
    https://dataprogrammingpro.herokuapp.com/api/students/

  - Fetch from https://gilded-sunflower-students.netlify.app/data.json and store in DB (GET Req)
    https://dataprogrammingpro.herokuapp.com/fetchandstoreindb/

  - GET Student by ID (GET Req)
    https://dataprogrammingpro.herokuapp.com/api/students/?id=-N-JeLpR19R18ng0kUKy

# step 3

- visualise data

- fit gap analysis

Use CORS Extension

https://chrome.google.com/webstore/detail/allow-cors-access-control/lhobafahddgcelffkeicbaginigeejlf?hl=en

---

# Install and other stuff

## For front end

`install node`
inside frontend folder
`num install`
`npm start`

## For backend

## Env Setup

`python3 -m venv dataproject`

### For Mac

`source ./dataproject/bin/activate`

### For Windows

`Search on google`

---

## installing dependencies

`pip install -r requirements.txt`

## to run server

`python manage.py runserver`

## migrate

#### `python3 manage.py makemigrations`

#### `python3 manage.py migrate`

## superuser

`python3 manage.py createsuperuser`

---

import collection in postman

> dataprodjango.postman_collection.json
