from django.contrib import admin
from .models import StudentItem

# Register your models here.
admin.site.register(StudentItem)
