from rest_framework import serializers
from .models import StudentItem


class StudentItemSerializer(serializers.ModelSerializer):
    student_name = serializers.CharField(required=True, max_length=200)
    student_enrollment = serializers.IntegerField(required=True)
    student_grades = serializers.IntegerField(required=True)

    class Meta:
        model = StudentItem
        fields = ('__all__')
