from django.urls import path
from .views import StudentItemViews

urlpatterns = [
    path('', StudentItemViews.as_view())
]
