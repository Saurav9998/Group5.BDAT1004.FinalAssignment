from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
import requests

import pyrebase

# Create your views here.
config = {
    "apiKey": "AIzaSyCe24aZQ_WDjhRYkl_EnS-sb44AseDYhS8",
    "authDomain": "data-programming-django.firebaseapp.com",
    "projectId": "data-programming-django",
    "storageBucket": "data-programming-django.appspot.com",
    "messagingSenderId": "43169257097",
    "appId": "1:43169257097:web:9f98fce6d8cf20a6749858",
    "databaseURL": "https://data-programming-django-default-rtdb.firebaseio.com/"
}

firebase = pyrebase.initialize_app(config)
authe = firebase.auth()
database = firebase.database()


class StudentItemViews(APIView):
    def get(self, request):
        data = requests.get(
            'https://gilded-sunflower-students.netlify.app/data.json')
        jsondata = data.json()
        for item in jsondata:
            database.child('Students').push(
                {
                    "student_name": item["student_name"],
                    "student_enrollment": item["student_enrollment"],
                    "student_grades": item["student_grades"]
                }

            )
        return Response({"status": "success", "data": "Successfully pushed in database!"}, status=status.HTTP_200_OK)
