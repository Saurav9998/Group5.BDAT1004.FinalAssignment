import Charts from "./components/home/graph";

function App() {
  return (
    <div className="App">
      <Charts />
    </div>
  );
}

export default App;
