import os
from django.apps import AppConfig

import schedule
import time


def job():
    print("I'm working...")


schedule.every().day.at("10:30").do(job)


class ApiAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api_app'

    # def ready(self):
    #     if os.environ.get('RUN_MAIN', None) != 'true':
    #         while True:
    #             schedule.run_pending()
    #             time.sleep(1)
