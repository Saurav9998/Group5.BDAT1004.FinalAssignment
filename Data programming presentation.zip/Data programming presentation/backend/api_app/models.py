from django.db import models

# Create your models here.


class StudentItem(models.Model):
    student_name = models.CharField(max_length=200)
    student_enrollment = models.PositiveIntegerField()
    student_grades = models.PositiveIntegerField()
