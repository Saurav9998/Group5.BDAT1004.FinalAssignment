from django.urls import path
from .views import StudentItemViews

urlpatterns = [
    path('students/', StudentItemViews.as_view())
]
