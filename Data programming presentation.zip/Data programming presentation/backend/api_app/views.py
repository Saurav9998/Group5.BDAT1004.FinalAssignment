from hashlib import new
from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .serializers import StudentItemSerializer
from .models import StudentItem

import pyrebase

# Create your views here.

config = {
    "apiKey": "AIzaSyCe24aZQ_WDjhRYkl_EnS-sb44AseDYhS8",
    "authDomain": "data-programming-django.firebaseapp.com",
    "projectId": "data-programming-django",
    "storageBucket": "data-programming-django.appspot.com",
    "messagingSenderId": "43169257097",
    "appId": "1:43169257097:web:9f98fce6d8cf20a6749858",
    "databaseURL": "https://data-programming-django-default-rtdb.firebaseio.com/"
}

firebase = pyrebase.initialize_app(config)
authe = firebase.auth()
database = firebase.database()


class StudentItemViews(APIView):
    def post(self, request):
        serializer = StudentItemSerializer(data=request.data)
        if serializer.is_valid():
            database.child('Students').push(request.data)
            return Response({"status": "success", "data": serializer.data}, status=status.HTTP_200_OK)
        else:
            return Response({"status": "error", "data": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request):
        data = 'No Data Found!'
        reqdata = request.GET
        if ('from' in reqdata and 'to' in reqdata):
            if(int(reqdata.get('from')) and int(reqdata.get('to'))):
                newdata = []
                data = database.child('Students').get().val()
                for obj in data:
                    if(data[obj]['student_enrollment'] >= int(reqdata.get('from')) and data[obj]['student_enrollment'] <= int(reqdata.get('to'))):
                        newdata.append(data[obj])
                data = newdata
            else:
                data = 'Enter integers only!'
        elif 'id' in reqdata:
            data = database.child('Students').child(
                reqdata.get('id')).get().val()
        else:
            data = database.child('Students').get().val()
        return Response({"status": "success", "data": data}, status=status.HTTP_200_OK)

    def delete(self, request):
        database.child('Students').remove()
        return Response({"status": "success", "data": "Data deleted successfully!"}, status=status.HTTP_200_OK)
