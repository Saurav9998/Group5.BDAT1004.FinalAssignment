from django.shortcuts import render
import pyrebase

config = {
    "apiKey": "AIzaSyCe24aZQ_WDjhRYkl_EnS-sb44AseDYhS8",
    "authDomain": "data-programming-django.firebaseapp.com",
    "projectId": "data-programming-django",
    "storageBucket": "data-programming-django.appspot.com",
    "messagingSenderId": "43169257097",
    "appId": "1:43169257097:web:9f98fce6d8cf20a6749858",
    "databaseURL": "https://data-programming-django-default-rtdb.firebaseio.com/"
}


firebase = pyrebase.initialize_app(config)
authe = firebase.auth()
database = firebase.database()


def home(request):
    projectname = database.child('Data').child('Projectname').get().val()
    return render(request, "home.html", {"projectname": projectname})
