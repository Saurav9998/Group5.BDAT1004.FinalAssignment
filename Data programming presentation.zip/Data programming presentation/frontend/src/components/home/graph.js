import React, { Component } from "react";
import { Chart } from "react-google-charts";
import axios from "axios";

export const options = {
  title: "Student's Performance",
  legend: { position: "bottom" },
};

class Charts extends Component {
  graphdata = [
    ["Names", "Marks"],
    ["Jinal", 91],
  ];
  newgraphdata = [];
  istrue = false;

  constructor(props) {
    super(props);
    this.state = {
      render: false, //Set render state to false
    };
  }

  async componentDidMount() {
    console.log("componentDidMount");
    let temp = [["Name", "Marks"]];
    axios({
      method: "get",
      url: "https://dataprogrammingpro.herokuapp.com/api/students/",
      responseType: "stream",
    }).then(function (response) {
      let json = response.data.data;
      console.log(json);
      if (json === null) {
        console.log("true");
        temp.push(["Xsc", 70], ["JPX", 85], ["SAU", 90], ["SUP", 75]);
      }
      for (const key in json) {
        if (Object.hasOwnProperty.call(json, key)) {
          const element = json[key];
          temp.push([element.student_name, element.student_grades]);
        }
      }
    });
    this.graphdata = temp;
    this.setState({});
    setTimeout(
      function () {
        //Start the timer
        this.setState({ render: true }); //After 1 second, set render to true
      }.bind(this),
      1000
    );
  }

  render() {
    //By default don't render anything
    if (this.state.render) {
      //If this.state.render == true, which is set to true by the timer.
      <div>Look at me! I'm content!</div>; //Add dom elements
    }
    return (
      <div className="graph-main">
        <div className="graph-container">
          <Chart
            chartType="ScatterChart"
            width="100%"
            height="400px"
            data={this.graphdata}
            options={options}
          />
          <Chart
            chartType="BarChart"
            width="100%"
            height="400px"
            data={this.graphdata}
            options={options}
          />
        </div>
      </div>
    );
  }
}

export default Charts;
